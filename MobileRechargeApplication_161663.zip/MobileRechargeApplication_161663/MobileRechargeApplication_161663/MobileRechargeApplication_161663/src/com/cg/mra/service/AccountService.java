/*Author : Garal Vashishtha
Application : Mobile Recharge Application
You Have Entered Service Interface Layer*/


package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileException;

public interface AccountService {

	Account getAccountDetails(String mobileNo);
	double rechargeAccount(String mobileno, double rechargeAmount);

	public boolean validateMobileNo(String mobileNo)throws MobileException;

	public boolean validateRechargeAmount(Double rechargeAmount)
			throws MobileException;


}

/*End Of Code*/