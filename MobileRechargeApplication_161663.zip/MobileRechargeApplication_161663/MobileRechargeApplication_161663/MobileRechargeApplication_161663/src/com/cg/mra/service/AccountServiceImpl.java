/*Author : Garal Vashishtha
Application : Mobile Recharge Application
You Have Entered Service Implementation Layer*/

package com.cg.mra.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.MobileException;

public class AccountServiceImpl implements AccountService 
{

	AccountDao dao;

	public AccountServiceImpl() {
		super();

		dao = new AccountDaoImpl();
	}


	@Override
	public Account getAccountDetails(String mobileNo) 
	{

		return dao.getAccountDetails(mobileNo);
	}

	@Override
	public double rechargeAccount(String mobileno, double rechargeAmount) 
	{

		return rechargeAmount;
	}

	/*Validating Mobile Number*/
	@Override
	public boolean validateMobileNo(String mobileNo) throws MobileException 
	{
		
		if(mobileNo == null)
			throw new MobileException("Null Value Found");
		Pattern p = Pattern.compile("[6789][0-9]{9}");
		Matcher m = p.matcher(mobileNo);
		return m.matches();
	}
	
	/*Validating Recharge Amount*/
	@Override
	public boolean validateRechargeAmount(Double rechargeAmount)throws MobileException 
	{

		if(rechargeAmount == null)
			throw new MobileException("Null Value Found");
		String ra = rechargeAmount.toString();
		return (ra.matches("\\d{2,9}\\.\\d{0,4}"));
	}

}

/*End Of Code*/
