/*Author : Garal Vashishtha
Application : Mobile Recharge Application
You Have Entered Presentation Layer*/


package com.cg.mra.ui;
import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI{
	public static void main(String args[]) {
		AccountService service = new AccountServiceImpl();
		Scanner sc = new Scanner(System.in); //Using the scanner to take inputs from the keyboard
		Account account = new Account();
		int ch = 0; 



		do{
			System.out.println("\n ~~~~ Welcome To Mobile Recharge Application ~~~~\n");
			System.out.println("\n Enter Your Choice :\n");
			System.out.println("1. Account Balance Enquiry :\n");
			System.out.println("2. Recharge Account :\n");
			System.out.println("3. Exit\n");
			ch = sc.nextInt();
			switch(ch) {

			case 1:

				System.out.println("Enter Mobile Number : ");
				String mobileno = sc.next();
				
				account = service.getAccountDetails(mobileno);
				if(account == null)
					System.err.println("ERROR: Given Account ID Does Not Exists");
				
				else{

					System.out.println("*------*------*------*------*------*------*------*");
					System.out.println("Your Current Balance is Rs. : " +account.getAccountBalance()); 
					System.out.println("*------*------*------*------*------*------*------*");
				}

				break;

			case 2:
				System.out.println("Enter Mobile Number : ");
				mobileno = sc.next();

				System.out.println("Enter The Amount To Be Recharged : ");
				double rechargeAmount = sc.nextDouble();
				account = service.getAccountDetails(mobileno);
				double recharge = service.rechargeAccount(mobileno, rechargeAmount);
				if(account == null){
					System.err.println("ERROR: Cannot Recharge Account As Given Mobile Number Does'nt Exists");
				}
				else{
					account.setAccountBalance(account.getAccountBalance()+recharge);
					System.out.println("*------*------*------*------*------*------*------*");
					System.out.println("Your Account Is Recharged Successfully");
					System.out.println("Hello "+account.getCustomerName() + ","+"Available Balance Is : "+account.getAccountBalance());
					System.out.println("*------*------*------*------*------*------*------*");
				}
				break;

			case 3:  System.out.println("*------*------*------*------*------*------*------*");
					 System.out.println("Exit -- Thanks For Choosing Our Application");
					 System.out.println("*------*------*------*------*------*------*------*");
			exit(0);
			break;

			}


		}while(ch!=3); 

	}

	private static void exit(int i) {


	}  



}

/*End Of Code*/


